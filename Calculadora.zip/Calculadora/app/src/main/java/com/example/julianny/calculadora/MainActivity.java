package com.example.julianny.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final EditText num1 = findViewById(R.id.editNum1);
        final EditText num2 = findViewById(R.id.editNum2);
        final TextView resultadoTotal = findViewById(R.id.textViewRes);
        Button soma = findViewById(R.id.btnSoma);
        Button subtracao = findViewById(R.id.btnSub);
        Button multiplicacao = findViewById(R.id.btnMul);
        Button divisao = findViewById(R.id.btnDiv);

        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float soma1 = Float.parseFloat(num1.getText().toString());
                Float soma2 = Float.parseFloat(num2.getText().toString());
                Float resultado = soma1 + soma2;
                resultadoTotal.setText(resultado.toString());


            }
        });
        subtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float subtracao1 = Float.parseFloat(num1.getText().toString());
                Float subtracao2 = Float.parseFloat(num2.getText().toString());
                Float resultado = subtracao1 - subtracao2;
                resultadoTotal.setText(resultado.toString());
            }
        });
        multiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float multiplicacao1 = Float.parseFloat(num1.getText().toString());
                Float multiplicacao2 = Float.parseFloat(num2.getText().toString());
                Float resultado = multiplicacao1 * multiplicacao2;
                resultadoTotal.setText(resultado.toString());
            }
        });
        divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float divisao1 = Float.parseFloat(num1.getText().toString());
                Float divisao2 = Float.parseFloat(num2.getText().toString());
                Float resultado = divisao1 / divisao2;
                resultadoTotal.setText(resultado.toString());
            }
        });

        Log.d("Debug","Esta dentro do onCreate");


    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Debug","Esta dentro do onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Debug","Esta dentro do onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Debug","Esta dentro do onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Debug","Esta dentro do onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Debug","Esta dentro do onDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Debug","Esta dentro do onRestart");
    }
}
